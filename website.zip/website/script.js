// Expand/Collapse Modules
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.module').forEach(module => {
        module.addEventListener('click', () => {
            const content = module.querySelector('.content');
            content.style.display = content.style.display === 'block' ? 'none' : 'block';
        });
    });
});

// Animated Particles Background
const canvas = document.getElementById('background');
const ctx = canvas.getContext('2d');

function resizeCanvas() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
}
resizeCanvas();
window.addEventListener('resize', resizeCanvas);

let particles = [];
for (let i = 0; i < 80; i++) {
    particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        r: Math.random() * 2
    });
}

function animateParticles() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = 'white';
    particles.forEach(p => {
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
        p.y += 0.3;
        if (p.y > canvas.height) p.y = 0;
    });
    requestAnimationFrame(animateParticles);
}
animateParticles();
